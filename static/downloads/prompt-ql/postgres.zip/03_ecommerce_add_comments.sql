-- Add descriptions to tables
COMMENT ON TABLE Users IS 'Stores information about users who have registered on the e-commerce platform, including personal details and authentication data.';
COMMENT ON TABLE Products IS 'Contains details of products available for sale, including name, category, price, and stock information.';
COMMENT ON TABLE Orders IS 'Records information about customer orders, including the user who placed the order, status, and total amount.';
COMMENT ON TABLE OrderItems IS 'Lists items associated with each order, including product, quantity, and unit price.';
COMMENT ON TABLE Reviews IS 'Stores user reviews for products, including ratings, comments, and optional vector embeddings for semantic analysis.';

-- Add descriptions to columns in the Users table
COMMENT ON COLUMN Users.user_id IS 'Unique identifier for each user.';
COMMENT ON COLUMN Users.first_name IS 'First name of the user.';
COMMENT ON COLUMN Users.last_name IS 'Last name of the user.';
COMMENT ON COLUMN Users.email IS 'Email address of the user, used for authentication and communication.';
COMMENT ON COLUMN Users.password IS 'Hashed password of the user, used for authentication.';
COMMENT ON COLUMN Users.created_at IS 'Timestamp when the user was created.';

-- Add descriptions to columns in the Products table
COMMENT ON COLUMN Products.product_id IS 'Unique identifier for each product.';
COMMENT ON COLUMN Products.product_name IS 'Name of the product.';
COMMENT ON COLUMN Products.category IS 'Category to which the product belongs, e.g., Electronics, Clothing and Apparel, Home and Kitchen, Beauty and Personal Care, Books, Toys and Games, Health and Wellness, Sports and Outdoors, Pet Supplies, Automotive Parts and Accessories';
COMMENT ON COLUMN Products.description IS 'Detailed description of the product.';
COMMENT ON COLUMN Products.price IS 'Price of the product in USD.';
COMMENT ON COLUMN Products.stock_quantity IS 'Number of units of the product available in stock.';
COMMENT ON COLUMN Products.created_at IS 'Timestamp when the product was added to the database.';

-- Add descriptions to columns in the Orders table
COMMENT ON COLUMN Orders.order_id IS 'Unique identifier for each order.';
COMMENT ON COLUMN Orders.user_id IS 'Identifier of the user who placed the order.';
COMMENT ON COLUMN Orders.order_date IS 'Timestamp when the order was placed.';
COMMENT ON COLUMN Orders.status IS 'Current status of the order, e.g., Pending, Completed, Shipped.';
COMMENT ON COLUMN Orders.total_amount IS 'Total monetary amount for the order.';

-- Add descriptions to columns in the OrderItems table
COMMENT ON COLUMN OrderItems.order_item_id IS 'Unique identifier for each item in an order.';
COMMENT ON COLUMN OrderItems.order_id IS 'Identifier of the order to which this item belongs.';
COMMENT ON COLUMN OrderItems.product_id IS 'Identifier of the product being purchased.';
COMMENT ON COLUMN OrderItems.quantity IS 'Quantity of the product ordered.';
COMMENT ON COLUMN OrderItems.unit_price IS 'Price per unit of the product at the time of order.';

-- Add descriptions to columns in the Reviews table
COMMENT ON COLUMN Reviews.review_id IS 'Unique identifier for each review.';
COMMENT ON COLUMN Reviews.product_id IS 'Identifier of the product being reviewed.';
COMMENT ON COLUMN Reviews.user_id IS 'Identifier of the user who wrote the review.';
COMMENT ON COLUMN Reviews.rating IS 'Rating given to the product by the user, on a scale of 1 to 5.';
COMMENT ON COLUMN Reviews.comment IS 'Textual feedback provided by the user about the product.';
COMMENT ON COLUMN Reviews.review_date IS 'Timestamp when the review was submitted.';
COMMENT ON COLUMN Reviews.embedding IS 'Vector embedding for the review text, used for semantic analysis and recommendation systems.';
